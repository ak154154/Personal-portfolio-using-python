# Flask Portfolio Web Application

This is a simple portfolio web application built using **Flask**, designed to showcase your skills, projects, and contact information.

## 🌐 Pages

- **Home** (`/`) – Welcome page
- **About** (`/about`) – Brief information about yourself
- **Projects** (`/projects`) – List of projects you've worked on
- **Contact** (`/contact`) – Contact form or information

## 🛠 Technologies Used

- **Python** with Flask
- **HTML** and **CSS**
- **Bootstrap** (optional for styling)

## 📁 Project Structure

```
portfolio_flask_app/
│
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── index.html
│   ├── about.html
│   ├── projects.html
│   └── contact.html
└── static/
    └── style.css
```

## 🚀 How to Run

1. **Clone or unzip the repository**

2. **Navigate to the project folder**
```bash
cd portfolio_flask_app
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Run the application**
```bash
python app.py
```

5. Open your browser and go to `http://127.0.0.1:5000`

---

Feel free to modify the templates and styles to better reflect your personal branding.
